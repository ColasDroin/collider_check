# Collider-check Package

## Overview

A small package that provides functions to check the observables in a collider, using a collider
built with [Xsuite](https://github.com/xsuite) as input (must be a json file). Very useful for
debugging purposes before/after tracking, and used as a backend of the [simulation dashboard](https://github.com/ColasDroin/simulation-dashboard).

## Installation

The package is available from PyPI, so you can install it with pip:

```bash
pip install collider-check
```
