# Package version
__version__ = "0.1.1"

# Import ColliderCheck class in the namespace
from .collider_check import ColliderCheck
